<h2>Niloy Garments</h2>
Your registration have been completed. <br>
Click below link for login <br>
<a href="{{url('login')}}">{{url('login')}}</a>
