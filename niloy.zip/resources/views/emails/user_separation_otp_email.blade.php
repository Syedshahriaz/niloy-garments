<h2>Niloy Garments</h2>
Your user separation OTP is: <br>
{{$otp}} <br>
Send this OTP to your admin to make you separate <br>
