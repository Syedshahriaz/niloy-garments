<h2>Niloy Garments</h2>
Dear <?php echo e($task->username); ?>: <br>
The original due date of your task have been past <br>
Complete your task or contact with admin <br>
Task Details <br>

<table>
    <tr>
        <td>Project: </td>
        <td><?php echo e($task->project_name); ?></td>
    </tr>
    <tr>
        <td>Task: </td>
        <td><?php echo e($task->title); ?></td>
    </tr>
    <tr>
        <td>Original Due Date: </td>
        <td><?php echo e(date('l, F d, Y', strtotime($task->original_delivery_date))); ?></td>
    </tr>
    <tr>
        <td>Username: </td>
        <td><?php echo e($task->username); ?></td>
    </tr>
    <tr>
        <td>User ID: </td>
        <td><?php echo e($task->unique_id); ?></td>
    </tr>
</table>
<?php /**PATH /var/www/html/niloy_garments/resources/views/emails/project_task_complete_past_warning_email.blade.php ENDPATH**/ ?>