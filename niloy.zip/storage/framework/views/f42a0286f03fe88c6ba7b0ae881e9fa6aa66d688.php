<?php $__env->startSection('title', 'All Projects'); ?>
<?php $__env->startSection('content'); ?>

    <!-- BEGIN CONTENT -->
    <div class="page-content-wrapper">
        <!-- BEGIN CONTENT BODY -->
        <div class="page-content">
            <!-- BEGIN PAGE HEADER-->
            <!-- BEGIN PAGE BAR -->
            <div class="page-bar">
                <ul class="page-breadcrumb">
                    <li>
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                        <i class="fa fa-circle"></i>
                    </li>
                    <li>
                        <span>All Projects</span>
                    </li>
                </ul>
                <div class="page-toolbar">
                </div>
            </div>

            <!-- BEGIN PAGE TITLE-->
            <!-- <h3 class="page-title"> Projects
                <small>dashboard &amp; statistics</small>
            </h3> -->
            <!-- END PAGE TITLE-->
            <!-- END PAGE BAR -->
            <!-- END PAGE HEADER-->

            <div class="row mt-3">
                <div class="col-md-12 col-sm-12">
                    <!-- BEGIN PORTLET-->
                    <div class="portlet light bordered">
                        <div class="portlet-title">
                            <div class="caption">
                                <i class="icon-share font-red-sunglo hide"></i>
                                <span class="caption-subject font-dark bold uppercase">All projects</span>
                                <span class="caption-helper">Select to add project</span>
                            </div>
                            <div class="actions">
                                <div class="user-list-tag">
                                    <ul>
                                        <?php $__currentLoopData = $child_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="<?php if($user->id==$user_id): ?> active <?php endif; ?>"><a href="<?php echo e(url('all_project').'?u_id='.$user->id); ?>" <?php if($user->shipment_date==''): ?> disabled <?php endif; ?>><?php echo e($user->username); ?></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="portlet-body">
                            <form id="project_form" method="post" action="">
                                <?php echo e(csrf_field()); ?>


                                <div class="alert alert-success" id="success_message" style="display:none"></div>
                                <div class="alert alert-danger" id="error_message" style="display: none"></div>
                                <div class="row">
                                    <?php
                                    foreach($projects as $project){

                                        if(!empty($project->running_task)){
                                            $task = $project->running_task;
                                        }
                                        else{
                                            $task = $project->last_task;
                                        }

                                        $bg_class = '';

                                        /*
                                         * Calculate number of days left to complete
                                         * */
                                        $now = time();
                                        $datediff = strtotime($task->original_delivery_date) - $now;
                                        $day_left = round($datediff / (60 * 60 * 24));

                                        /*
                                         * Create bg class
                                         * */
                                        if($task->status == 'completed'){
                                            $bg_class = 'bg-success';
                                        }
                                        else{
                                            if(strtotime($task->original_delivery_date) < time()) {
                                                $bg_class = 'bg-danger';
                                            }
                                            else if($day_left<=7){
                                                $bg_class = 'bg-warning';
                                            }
                                        }
                                    ?>
                                    <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
                                        <a class="project-item-title" href="<?php echo e(url('my_project_task',$project->user_project_id)); ?>" title="<?php echo e($project->name); ?>">
                                            <div class="dashboard-stat2 project-item <?php echo e($bg_class); ?>">
                                                <div class="display title-section">
                                                    <div class="number">
                                                        <h5 class="font-theme project-item-name">
                                                            <?php echo e($project->name); ?>

                                                        </h5>
                                                    </div>
                                                    <div class="icon">
                                                        <!-- <a href="javascript:;" title="Favourite" class="add_to_fav">
                                                            <i class="icon-heart"></i>
                                                        </a> -->
                                                        <i class="icon-arrow-right"></i>
                                                    </div>
                                                </div>
                                                <div class="display">
                                                    <p class="project-item-sub" title="This is a sub title"><?php echo e($project->sub_title); ?></p>
                                                    <p class="project-item-task font-theme"><?php echo e($task->title); ?></p>
                                                </div>
                                                <div class="progress-info">
                                                    <div class="progress">
                                                        <span style="width: 100%;" class="progress-bar theme-bg"></span>
                                                    </div>
                                                    <div class="status">
                                                        <div class="status-title"> Due Date </div>
                                                        <div class="status-number"> <?php echo e(date('l M d, Y', strtotime($task->original_delivery_date))); ?></div>
                                                        <input type="hidden" name="start_dates[]" value="<?php echo e(date('Y-m-d', strtotime($task->original_delivery_date))); ?>">
                                                    </div>
                                                </div>
                                                <input type="hidden" class="project-item-check" name="project_check[]" value="0">
                                                <input type="hidden" class="project-item-id" name="project_id[]" value="<?php echo e($project->id); ?>">
                                            </div>
                                        </a>
                                    </div>
                                    <?php
                                    }
                                    ?>
                                </div>
                                <!-- <div class="row">
                                    <div class="col-md-12 text-right">
                                        <button type="submit" class="btn green">Add Selected Project</button>
                                    </div>
                                </div> -->
                            </form>
                        </div>
                    </div>
                    <!-- END PORTLET-->
                </div>
            </div>

        </div>
        <!-- END CONTENT BODY -->
    </div>
    <!-- END CONTENT -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(document).on("submit", "#project_form", function(event) {
            event.preventDefault();
            var options = {
                theme: "sk-cube-grid",
                message: 'Please wait while saving all data.....',
                backgroundColor: "#1847B1",
                textColor: "white"
            };

            HoldOn.open(options);

            var validate = "";

            if (validate == "") {
                var formData = new FormData($("#project_form")[0]);
                var url = "<?php echo e(url('add_project')); ?>";

                $.ajax({
                    type: "POST",
                    url: url,
                    data: formData,
                    success: function(data) {
                        HoldOn.close();
                        if (data.status == 200) {
                            $("#success_message").show();
                            $("#error_message").hide();
                            $("#success_message").html(data.reason);
                            setTimeout(function(){
                                window.location.href = "<?php echo e(url('my_project')); ?>";
                            },2000)
                        } else {
                            $("#success_message").hide();
                            $("#error_message").show();
                            $("#error_message").html(data.reason);
                        }
                    },
                    error: function(data) {
                        HoldOn.close();
                        $("#success_message").hide();
                        $("#error_message").show();
                        $("#error_message").html(data);
                    },
                    cache: false,
                    contentType: false,
                    processData: false
                });
            } else {
                HoldOn.close();
                $("#success_message").hide();
                $("#error_message").show();
                $("#error_message").html(validate);
            }
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/niloy_garments/resources/views/user/project/all_project.blade.php ENDPATH**/ ?>