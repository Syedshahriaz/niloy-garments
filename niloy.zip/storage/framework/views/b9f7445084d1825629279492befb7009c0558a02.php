<h2>Niloy Garments</h2>
Your registration have been completed. <br>
Click below link for login <br>
<a href="<?php echo e(url('login')); ?>"><?php echo e(url('login')); ?></a>
<?php /**PATH /var/www/html/niloy_garments/resources/views/emails/registration_confirmation_email.blade.php ENDPATH**/ ?>