<h2>Niloy Garments</h2>
Your user separation OTP is: <br>
<?php echo e($otp); ?> <br>
Send this OTP to your admin to make you separate <br>
<?php /**PATH /var/www/html/niloy_garments/resources/views/emails/user_separation_otp_email.blade.php ENDPATH**/ ?>