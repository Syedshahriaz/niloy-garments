
</div>
<!-- END CONTAINER -->
<div class="page-footer">
    <div class="page-footer-inner"> 2020 &copy;</div>
    <div class="scroll-to-top">
        <i class="icon-arrow-up"></i>
    </div>
</div>

<!-- BEGIN FOOTER scripts-->
<?php echo $__env->make('partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- END FOOTER scripts-->
</body>

</html>
<?php /**PATH /var/www/html/niloy/resources/views/partials/footer.blade.php ENDPATH**/ ?>